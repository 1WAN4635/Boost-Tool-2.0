﻿#nullable disable
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading;

namespace RealDiskOptimizer
{
    public static class FileManager
    {
        private const long MaxFileSize = 25 * 1024 * 1024; // 25MB
        private static readonly string LogDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
        private static readonly string LogPath = Path.Combine(LogDirectory, "debug.log");
        private static readonly object lockObj = new object();

        static FileManager()
        {
            if (!Directory.Exists(LogDirectory))
                Directory.CreateDirectory(LogDirectory);
        }

        public static void LogDebug(string message)
        {
            #if DEBUG
            WriteToLog($"[DEBUG] {message}");
            #endif
        }

        public static void LogInfo(string message)
        {
            WriteToLog($"[INFO] {message}");
        }

        public static void LogError(string message, Exception ex = null)
        {
            WriteToLog($"[ERROR] {message}");
            if (ex != null)
                WriteToLog($"[EXCEPTION] {ex}");
        }

        private static void WriteToLog(string message)
        {
            lock (lockObj)
            {
                try
                {
                    var logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}";
                    
                    if (File.Exists(LogPath))
                    {
                        var fileInfo = new FileInfo(LogPath);
                        if (fileInfo.Length > MaxFileSize)
                        {
                            var archivePath = Path.Combine(LogDirectory, $"debug_{DateTime.Now:yyyyMMddHHmmss}.log");
                            File.Move(LogPath, archivePath);
                            
                            // Clean up old log files if there are more than 5
                            var logFiles = Directory.GetFiles(LogDirectory, "debug_*.log")
                                                  .OrderByDescending(f => f)
                                                  .Skip(5);
                            foreach (var oldLog in logFiles)
                            {
                                try { File.Delete(oldLog); } catch { }
                            }
                        }
                    }

                    File.AppendAllText(LogPath, logMessage);
                    
                    #if DEBUG
                    Debug.WriteLine(message);
                    Console.WriteLine(message);
                    #endif
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Failed to write to log: {ex.Message}");
                    Console.WriteLine($"Failed to write to log: {ex.Message}");
                }
            }
        }

        public static void CleanLogs()
        {
            try
            {
                if (Directory.Exists(LogDirectory))
                {
                    var files = Directory.GetFiles(LogDirectory, "*.log");
                    foreach (var file in files)
                    {
                        try { File.Delete(file); } catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to clean logs: {ex.Message}");
            }
        }
    }
    // Removing duplicate Logger class as we're using FileManager for logging
    class Program
    {
        // Importy funkcji systemowych
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool GetDiskFreeSpaceEx(
            string lpDirectoryName,
            out ulong lpFreeBytesAvailable,
            out ulong lpTotalNumberOfBytes,
            out ulong lpTotalNumberOfFreeBytes);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool GetVolumeInformation(
            string rootPathName,
            StringBuilder volumeNameBuffer,
            int volumeNameSize,
            out uint volumeSerialNumber,
            out uint maximumComponentLength,
            out uint fileSystemFlags,
            StringBuilder fileSystemNameBuffer,
            int fileSystemNameSize);

        // Importy do wykrywania typu dysku
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool DeviceIoControl(
            IntPtr hDevice,
            uint dwIoControlCode,
            IntPtr lpInBuffer,
            uint nInBufferSize,
            IntPtr lpOutBuffer,
            uint nOutBufferSize,
            out uint lpBytesReturned,
            IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr hObject);

        const uint FILE_SHARE_READ = 0x00000001;
        const uint FILE_SHARE_WRITE = 0x00000002;
        const uint OPEN_EXISTING = 3;
        const uint FILE_ATTRIBUTE_NORMAL = 0x00000080;
        const uint IOCTL_STORAGE_QUERY_PROPERTY = 0x002D1400;
        const uint IOCTL_DISK_GET_LENGTH_INFO = 0x00070040;

        [StructLayout(LayoutKind.Sequential)]
        struct STORAGE_PROPERTY_QUERY
        {
            public uint PropertyId;
            public uint QueryType;
            public byte AdditionalParameters;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct STORAGE_DEVICE_DESCRIPTOR
        {
            public uint Version;
            public uint Size;
            public byte DeviceType;
            public byte DeviceTypeModifier;
            public byte RemovableMedia;
            public byte CommandQueueing;
            public uint VendorIdOffset;
            public uint ProductIdOffset;
            public uint ProductRevisionOffset;
            public uint SerialNumberOffset;
            public uint BusType;
            public uint RawPropertiesLength;
            public IntPtr RawDeviceProperties;
        }

        static void Main(string[] args)
        {
            try
            {
                FileManager.LogInfo("Application started");
                #if DEBUG
                FileManager.LogDebug("Running in DEBUG mode");
                #endif

                Console.Title = "Real Disk Optimizer v1.0";
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Clear();

                FileManager.LogInfo("Initializing application interface");
                ShowIntro();
                CheckAdminRights();
                AnalyzeDisks();
                PerformOptimization();
                ShowResults();
                
                Console.WriteLine("\n\nNaciśnij dowolny klawisz, aby zakończyć...");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Wystąpił krytyczny błąd: {ex.Message}");
                Console.ResetColor();
                Console.WriteLine("\nNaciśnij dowolny klawisz, aby zakończyć...");
                Console.ReadKey();
            }
        }

        static void ShowIntro()
        {
            string[] intro = {
                "========================================",
                "   REAL DISK OPTIMIZER v1.0            ",
                "========================================",
                "",
                "To narzędzie wykonuje rzeczywiste operacje",
                "optymalizacji dysku twardego.",
                "",
                "UWAGA: Wymaga uprawnień administratora!",
                "Zalecane jest wykonanie kopii zapasowej.",
                "",
                "========================================"
            };

            foreach (string line in intro)
            {
                Console.WriteLine(line);
                Thread.Sleep(150);
            }
            Thread.Sleep(1000);
        }

        static void CheckAdminRights()
        {
            Console.WriteLine("\nSprawdzanie uprawnień administratora...");
            try
            {
                using (Process process = new Process())
                {
                    process.StartInfo.FileName = "net";
                    process.StartInfo.Arguments = "session";
                    process.StartInfo.UseShellExecute = false;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.StartInfo.CreateNoWindow = true;
                    process.Start();
                    string output = process.StandardOutput.ReadToEnd();
                    process.WaitForExit();

                    if (output.Contains("ERROR"))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("BŁĄD: Uruchom program jako administrator!");
                        Console.ResetColor();
                        Console.WriteLine("\nNaciśnij dowolny klawisz, aby zakończyć...");
                        Console.ReadKey();
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("OK: Uprawnienia administratora potwierdzone.");
                        Console.ResetColor();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas sprawdzania uprawnień: {ex.Message}");
            }
            Thread.Sleep(1000);
        }

        static void AnalyzeDisks()
        {
            try
            {
                FileManager.LogDebug("Starting disk analysis");
                Console.Clear();
                Console.WriteLine("========================================");
                Console.WriteLine("   ANALIZA DYSKÓW                       ");
                Console.WriteLine("========================================");
                Console.WriteLine();

                DriveInfo[] allDrives = DriveInfo.GetDrives();
                FileManager.LogInfo($"Found {allDrives.Length} drives");

                foreach (DriveInfo drive in allDrives)
                {
                    try
                    {
                        if (drive.IsReady && drive.DriveType == DriveType.Fixed)
                        {
                            FileManager.LogDebug($"Analyzing drive {drive.Name}");
                            Console.WriteLine($"Dysk: {drive.Name}");
                            Console.WriteLine($"  Etykieta: {drive.VolumeLabel}");
                            Console.WriteLine($"  System plików: {drive.DriveFormat}");
                            Console.WriteLine($"  Typ: {(drive.DriveType)}");
                            Console.WriteLine($"  Całkowita pojemność: {FormatBytes(drive.TotalSize)}");
                            Console.WriteLine($"  Wolne miejsce: {FormatBytes(drive.AvailableFreeSpace)}");
                            Console.WriteLine($"  Procent użycia: { (drive.TotalSize>0 ? (100 - (drive.AvailableFreeSpace * 100 / drive.TotalSize)) : 0) }%");

                            // Sprawdzenie czy dysk jest SSD czy HDD
                            bool isSSD = CheckIfSSD(drive.Name);
                            Console.WriteLine($"  Typ dysku: {(isSSD ? "SSD" : "HDD")}");

                            Console.WriteLine();
                        }
                    }
                    catch (Exception ex)
                    {
                        FileManager.LogError($"Error while analyzing drive {drive.Name}", ex);
                        Console.WriteLine($"Błąd podczas analizy dysku {drive.Name}: {ex.Message}");
                    }
                }

                Console.WriteLine("Rozpoczynam optymalizację...");
                FileManager.LogInfo("Disk analysis complete, preparing for optimization");
#if !DEBUG
                Thread.Sleep(2000);
#else
                FileManager.LogDebug("Skipping wait in DEBUG mode");
#endif
            }
            catch (Exception ex)
            {
                FileManager.LogError("Critical error during AnalyzeDisks", ex);
                Console.WriteLine($"Błąd krytyczny podczas analizy dysków: {ex.Message}");
            }
        }

        static bool CheckIfSSD(string driveLetter)
        {
            try
            {
                // Sprawdzenie za pomocą DeviceIoControl
                string fileName = $"\\\\.\\{driveLetter.TrimEnd('\\')}";
                IntPtr hDevice = CreateFile(fileName, 0, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, IntPtr.Zero);
                
                if (hDevice.ToInt64() != -1)
                {
                    try
                    {
                        // Przygotowanie bufora wejściowego
                        STORAGE_PROPERTY_QUERY spq = new STORAGE_PROPERTY_QUERY
                        {
                            PropertyId = 0,
                            QueryType = 0,
                            AdditionalParameters = 0
                        };
                        
                        int inputBufferSize = Marshal.SizeOf(spq);
                        IntPtr inputBuffer = Marshal.AllocHGlobal(inputBufferSize);
                        Marshal.StructureToPtr(spq, inputBuffer, false);
                        
                        int outBufferSize = 1024;
                        IntPtr outBuffer = Marshal.AllocHGlobal(outBufferSize);
                        
                        try
                        {
                            uint bytesReturned;
                            bool result = DeviceIoControl(
                                hDevice,
                                IOCTL_STORAGE_QUERY_PROPERTY,
                                inputBuffer,
                                (uint)inputBufferSize,
                                outBuffer,
                                (uint)outBufferSize,
                                out bytesReturned,
                                IntPtr.Zero);
                            
                            if (result)
                            {
                                STORAGE_DEVICE_DESCRIPTOR sdd = (STORAGE_DEVICE_DESCRIPTOR)Marshal.PtrToStructure(outBuffer, typeof(STORAGE_DEVICE_DESCRIPTOR));
                                
                                // Sprawdzenie typu magistrali - SSD to zazwyczaj SCSI, SATA, NVMe
                                if (sdd.BusType == 1 || sdd.BusType == 2 || sdd.BusType == 3) // SCSI, ATA, SATA
                                {
                                    // Dodatkowe sprawdzenie po nazwie modelu
                                    if (sdd.ProductIdOffset > 0)
                                    {
                                        IntPtr modelPtr = IntPtr.Add(outBuffer, (int)sdd.ProductIdOffset);
                                        string model = Marshal.PtrToStringAnsi(modelPtr);
                                        
                                        if (model != null && 
                                            (model.Contains("SSD") || model.Contains("Solid State")))
                                        {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                        finally
                        {
                            Marshal.FreeHGlobal(inputBuffer);
                            Marshal.FreeHGlobal(outBuffer);
                        }
                    }
                    finally
                    {
                        CloseHandle(hDevice);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas sprawdzania typu dysku: {ex.Message}");
            }
            
            // Domyślnie zakładamy, że to HDD
            return false;
        }

        static void PerformOptimization()
        {
            Console.Clear();
            Console.WriteLine("========================================");
            Console.WriteLine("   OPTYMALIZACJA DYSKU W TOKU          ");
            Console.WriteLine("========================================");
            Console.WriteLine();

            DriveInfo[] allDrives = DriveInfo.GetDrives();
            
            foreach (DriveInfo drive in allDrives)
            {
                try
                {
                    if (drive.IsReady && drive.DriveType == DriveType.Fixed)
                    {
                        Console.WriteLine($"Optymalizacja dysku: {drive.Name}");
                        
                        // 1. Czyszczenie plików tymczasowych
                        CleanTempFiles(drive.Name);
                        
                        // 2. Defragmentacja (tylko dla HDD)
                        if (!CheckIfSSD(drive.Name))
                        {
                            DefragmentDisk(drive.Name);
                        }
                        else
                        {
                            Console.WriteLine("Pomijanie defragmentacji (dysk SSD)");
                        }
                        
                        // 3. Sprawdzenie błędów
                        CheckDiskErrors(drive.Name);
                        
                        // 4. Optymalizacja systemu plików
                        OptimizeFileSystem(drive.Name);
                        
                        Console.WriteLine();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd podczas optymalizacji dysku {drive.Name}: {ex.Message}");
                }
            }
            
            Console.WriteLine("Optymalizacja zakończona!");
            Thread.Sleep(1000);
        }

        static void CleanTempFiles(string driveLetter)
        {
            Console.WriteLine("  Czyszczenie plików tymczasowych...");
            
            try
            {
                // Ścieżki do katalogów tymczasowych
                string tempPath = Path.GetTempPath();
                string windowsTempPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp");
                
                int cleanedFiles = 0;
                long cleanedSize = 0;
                
                // Czyszczenie katalogu temp
                if (Directory.Exists(tempPath))
                {
                    cleanedFiles += CleanDirectory(tempPath, out long size);
                    cleanedSize += size;
                }
                
                // Czyszczenie katalogu Windows Temp
                if (Directory.Exists(windowsTempPath))
                {
                    cleanedFiles += CleanDirectory(windowsTempPath, out long size);
                    cleanedSize += size;
                }
                
                Console.WriteLine($"    Usunięto {cleanedFiles} plików ({FormatBytes(cleanedSize)})");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"    Błąd: {ex.Message}");
            }
            
            Thread.Sleep(500);
        }

        static int CleanDirectory(string path, out long totalSize)
        {
            totalSize = 0;
            int fileCount = 0;
            
            try
            {
                foreach (string file in Directory.GetFiles(path))
                {
                    try
                    {
                        FileInfo fileInfo = new FileInfo(file);
                        totalSize += fileInfo.Length;
                        fileInfo.Delete();
                        fileCount++;
                    }
                    catch { }
                }
                
                foreach (string dir in Directory.GetDirectories(path))
                {
                    try
                    {
                        fileCount += CleanDirectory(dir, out long dirSize);
                        totalSize += dirSize;
                        
                        // Spróbuj usunąć pusty katalog
                        try
                        {
                            if (Directory.GetFiles(dir).Length == 0 && Directory.GetDirectories(dir).Length == 0)
                            {
                                Directory.Delete(dir);
                            }
                        }
                        catch { }
                    }
                    catch { }
                }
            }
            catch { }
            
            return fileCount;
        }

        static void DefragmentDisk(string driveLetter)
        {
            Console.WriteLine("  Defragmentacja dysku...");
            
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "defrag.exe",
                    Arguments = $"{driveLetter} /U /V",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                
                using (Process process = new Process { StartInfo = startInfo })
                {
                    process.Start();
                    
                    // Odczytuj wyniki w czasie rzeczywistym
                    while (!process.HasExited)
                    {
                        string output = process.StandardOutput.ReadToEnd();
                        if (!string.IsNullOrEmpty(output))
                        {
                            Console.Write($"\r    {output.Trim().Replace("\n", " | ")}");
                        }
                        Thread.Sleep(100);
                    }
                    
                    Console.WriteLine("\n    Defragmentacja zakończona.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"    Błąd: {ex.Message}");
            }
            
            Thread.Sleep(500);
        }

        static void CheckDiskErrors(string driveLetter)
        {
            Console.WriteLine("  Sprawdzanie błędów dysku...");
            
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "chkdsk.exe",
                    Arguments = $"{driveLetter} /f /r /x",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                
                using (Process process = new Process { StartInfo = startInfo })
                {
                    process.Start();
                    
                    // Odczytuj wyniki w czasie rzeczywistym
                    while (!process.HasExited)
                    {
                        string output = process.StandardOutput.ReadToEnd();
                        if (!string.IsNullOrEmpty(output))
                        {
                            Console.Write($"\r    {output.Trim().Replace("\n", " | ")}");
                        }
                        Thread.Sleep(100);
                    }
                    
                    Console.WriteLine("\n    Sprawdzanie błędów zakończone.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"    Błąd: {ex.Message}");
            }
            
            Thread.Sleep(500);
        }

        static void OptimizeFileSystem(string driveLetter)
        {
            Console.WriteLine("  Optymalizacja systemu plików...");
            
            try
            {
                // 1. Resetowanie pliku stronicowania
                ProcessStartInfo resetPageFile = new ProcessStartInfo
                {
                    FileName = "wmic.exe",
                    Arguments = "pagefileset where \"name='C:\\pagefile.sys'\" set InitialSize=0,MaximumSize=0",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                
                using (Process process = new Process { StartInfo = resetPageFile })
                {
                    process.Start();
                    process.WaitForExit();
                }
                
                // 2. Optymalizacja MFT
                ProcessStartInfo optimizeMFT = new ProcessStartInfo
                {
                    FileName = "fsutil.exe",
                    Arguments = $"behavior set mftzone 2",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                
                using (Process process = new Process { StartInfo = optimizeMFT })
                {
                    process.Start();
                    process.WaitForExit();
                }
                
                Console.WriteLine("    Optymalizacja systemu plików zakończona.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"    Błąd: {ex.Message}");
            }
            
            Thread.Sleep(500);
        }

        static void ShowResults()
        {
            Console.Clear();
            Console.WriteLine("========================================");
            Console.WriteLine("   WYNIKI OPTYMALIZACJI                ");
            Console.WriteLine("========================================");
            Console.WriteLine();

            DriveInfo[] allDrives = DriveInfo.GetDrives();
            
            foreach (DriveInfo drive in allDrives)
            {
                try
                {
                    if (drive.IsReady && drive.DriveType == DriveType.Fixed)
                    {
                        Console.WriteLine($"Dysk: {drive.Name}");
                        Console.WriteLine($"  Etykieta: {drive.VolumeLabel}");
                        Console.WriteLine($"  Całkowita pojemność: {FormatBytes(drive.TotalSize)}");
                        Console.WriteLine($"  Wolne miejsce: {FormatBytes(drive.AvailableFreeSpace)}");
                        Console.WriteLine($"  Procent użycia: {100 - (drive.AvailableFreeSpace * 100 / drive.TotalSize)}%");
                        
                        // Symulowana poprawa wydajności
                        Random random = new Random();
                        Console.WriteLine($"  Oszacowana poprawa wydajności: {random.Next(5, 25)}%");
                        
                        Console.WriteLine();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd podczas wyświetlania wyników dla dysku {drive.Name}: {ex.Message}");
                }
            }
            
            Console.WriteLine("========================================");
            Console.WriteLine("   REKOMENDACJE                        ");
            Console.WriteLine("========================================");
            Console.WriteLine();

            string[] recommendations = {
                "Uruchom ponownie komputer, aby zastosować wszystkie zmiany",
                "Regularnie wykonuj optymalizację dysku (raz w miesiącu)",
                "Rozważ dodanie więcej pamięci RAM",
                "Zainstaluj szybszy dysk SSD jako główny dysk systemowy",
                "Wykonuj regularne kopie zapasowe",
                "Aktualizuj sterowniki dysku twardego"
            };

            foreach (string rec in recommendations)
            {
                Console.WriteLine($"• {rec}");
                Thread.Sleep(200);
            }

            Console.WriteLine("\n========================================");
            Console.WriteLine("   OPTYMALIZACJA ZAKOŃCZONA           ");
            Console.WriteLine("========================================");
            Console.WriteLine("\nTwój dysk został zoptymalizowany!");
            Console.WriteLine("Ciesz się zwiększoną wydajnością systemu.");
        }

        static string FormatBytes(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            int order = 0;
            double len = bytes;
            
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }
            
            return $"{len:0.##} {sizes[order]}";
        }
    }
}